create function ri_4_proc() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (NEW.address IN (SELECT address FROM office) AND NEW.address IN (SELECT address FROM warehouse)) OR
       (NEW.address NOT IN (SELECT address FROM office) AND NEW.address NOT IN (SELECT address FROM warehouse)) THEN
        RAISE EXCEPTION 'Um Workplace deve ser obrigatoriamente um Office ou Warehouse, mas não pode ser ambos.';
    END IF;
    RETURN NEW;
END;
$$;

alter function ri_4_proc() owner to ist1103641;

