create function ri_1_proc() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.bdate > CURRENT_DATE - INTERVAL '18 years' THEN
        RAISE EXCEPTION 'Nenhum empregado pode ter menos de 18 anos de idade';
    END IF;
    RETURN NEW;
END;
$$;

alter function ri_1_proc() owner to ist1103641;

