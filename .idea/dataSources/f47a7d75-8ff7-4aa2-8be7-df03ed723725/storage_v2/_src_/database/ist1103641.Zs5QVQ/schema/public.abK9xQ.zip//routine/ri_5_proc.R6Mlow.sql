create function ri_5_proc() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM contains
        WHERE order_no = NEW.order_no
    ) THEN
        RAISE EXCEPTION 'Uma Order deve figurar obrigatoriamente em Contains.';
    END IF;
    RETURN NEW;
END;
$$;

alter function ri_5_proc() owner to ist1103641;

