create function ri_5_proc() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.order_no NOT IN (
        SELECT order_no
        FROM contains
    )THEN
        RAISE EXCEPTION 'Uma Order tem de figurar obrigatoriamente em Contains.';
    END IF;
    RETURN NEW;
END;
$$;

alter function ri_5_proc() owner to ist1103641;

